# -*- coding: utf-8 -*-
EXIF_DATA_PARSER='exif_model.parser.GExiv2Parser'
