=================
Django exif model
=================

Customizable Django model for storing EXIF data.
