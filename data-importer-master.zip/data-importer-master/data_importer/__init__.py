# encoding: utf-8
__doc__ = 'Data Importer'
__version__ = '3.0.2'
__author__ = 'Valder Gallo <valdergallo@gmail.com>'
