Core
====

.. toctree::
   :maxdepth: 2

   core/base
   core/default_settings
   core/exceptions
   core/descriptor
