XLSReader
=========

.. automodule:: data_importer.readers.xls_importer
    :members:
    :inherited-members:
