Data Importer Forms
===================

    Is one simple django.ModelForm with content to upload content

    :Parameters:
        * content (`FileField`)  File uploaded


FileUploadForm
--------------

.. automodule:: data_importer.forms
    :members:
    :undoc-members:
    :inherited-members:
