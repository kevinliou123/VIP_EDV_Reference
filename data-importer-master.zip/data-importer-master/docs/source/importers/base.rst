BaseImporter
============

.. automodule:: data_importer.importers.base
    :members:
    :inherited-members:
