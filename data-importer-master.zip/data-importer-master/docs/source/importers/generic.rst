GenericImporter
===============

.. automodule:: data_importer.importers.generic
    :members:
    :undoc-members:
    :inherited-members:
