Descriptors
===========

.. automodule:: data_importer.core.descriptor
    :members:
    :undoc-members:
    :inherited-members:
